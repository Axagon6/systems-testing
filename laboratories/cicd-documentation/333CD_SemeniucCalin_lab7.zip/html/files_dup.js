var files_dup =
[
    [ "main.py", "main_8py.html", "main_8py" ],
    [ "node.py", "node_8py.html", "node_8py" ],
    [ "test_tree.py", "test__tree_8py.html", "test__tree_8py" ],
    [ "tree.py", "tree_8py.html", "tree_8py" ]
];