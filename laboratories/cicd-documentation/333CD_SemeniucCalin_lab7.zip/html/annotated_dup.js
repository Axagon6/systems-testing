var annotated_dup =
[
    [ "node", "namespacenode.html", [
      [ "Node", "classnode_1_1Node.html", "classnode_1_1Node" ]
    ] ],
    [ "test_tree", "namespacetest__tree.html", [
      [ "TestTree", "classtest__tree_1_1TestTree.html", "classtest__tree_1_1TestTree" ]
    ] ],
    [ "tree", "namespacetree.html", [
      [ "Tree", "classtree_1_1Tree.html", "classtree_1_1Tree" ]
    ] ]
];