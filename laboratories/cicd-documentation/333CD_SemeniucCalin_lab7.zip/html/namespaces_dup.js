var namespaces_dup =
[
    [ "main", "namespacemain.html", [
      [ "tree", "namespacemain.html#a5a27d320c4707471b0d3a04a51abf6ae", null ]
    ] ],
    [ "node", "namespacenode.html", "namespacenode" ],
    [ "test_tree", "namespacetest__tree.html", "namespacetest__tree" ],
    [ "tree", "namespacetree.html", "namespacetree" ]
];