var hierarchy =
[
    [ "node.Node", "classnode_1_1Node.html", null ],
    [ "unittest.TestCase", null, [
      [ "test_tree.TestTree", "classtest__tree_1_1TestTree.html", null ]
    ] ],
    [ "tree.Tree", "classtree_1_1Tree.html", null ]
];