var searchData=
[
  ['getroot_0',['getRoot',['../classtree_1_1Tree.html#a346c463a50c3a054b832cb8c2c9e326a',1,'tree::Tree']]]
];
