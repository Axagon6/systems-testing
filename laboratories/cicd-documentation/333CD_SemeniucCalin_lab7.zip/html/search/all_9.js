var searchData=
[
  ['right_0',['right',['../classnode_1_1Node.html#a19b985553662bfd3d1eaa009d7bb6af3',1,'node::Node']]],
  ['root_1',['root',['../classtree_1_1Tree.html#af113725032a5affae34a81564874dca5',1,'tree::Tree']]]
];
