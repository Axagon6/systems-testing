var searchData=
[
  ['add_0',['add',['../classtree_1_1Tree.html#a2771580889b84268fb517d4c04f52a40',1,'tree::Tree']]]
];
