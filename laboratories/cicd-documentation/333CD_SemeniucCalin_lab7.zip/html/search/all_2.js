var searchData=
[
  ['data_0',['data',['../classnode_1_1Node.html#aa357f0c11267a6352c53fe6af60fa06e',1,'node::Node']]],
  ['deletetree_1',['deleteTree',['../classtree_1_1Tree.html#a2e102f61f0ea74650da7264e03e41597',1,'tree::Tree']]]
];
