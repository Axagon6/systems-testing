class Node:
    """ Node class for binary tree """

    def __init__(self, data):
        self.left = None
        self.right = None
        self.data = data

